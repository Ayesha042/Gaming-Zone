
let score = localStorage.getItem("score") || 0;
document.getElementById("score") && (document.getElementById("score").innerText = score);
document.getElementById("best") && (document.getElementById("best").innerText = score);

function addScore(){
score++;
localStorage.setItem("score", score);
document.getElementById("score").innerText = score;
}
